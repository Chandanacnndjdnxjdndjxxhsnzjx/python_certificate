# python_project_certificate


To install any package 
"""
pip install -r requriment.txt

"""